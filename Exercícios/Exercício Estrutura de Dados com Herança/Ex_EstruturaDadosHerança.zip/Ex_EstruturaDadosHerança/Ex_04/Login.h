#pragma once
#include "Menu.h"
class Login :
	public SubMenu
{
public:
	Login();
	~Login();
};


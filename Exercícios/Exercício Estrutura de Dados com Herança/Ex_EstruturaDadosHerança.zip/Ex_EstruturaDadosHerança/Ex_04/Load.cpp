#include "Load.h"



Load::Load()
{
}


Load::~Load()
{
}

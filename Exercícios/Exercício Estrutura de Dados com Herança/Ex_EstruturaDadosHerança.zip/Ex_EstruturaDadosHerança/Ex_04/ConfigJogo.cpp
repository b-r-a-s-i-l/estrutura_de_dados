#include "ConfigJogo.h"



ConfigJogo::ConfigJogo()
{
}


ConfigJogo::~ConfigJogo()
{
}

#pragma once
#include "Menu.h"
class Save :
	public SubMenu
{
public:
	Save();
	~Save();
};


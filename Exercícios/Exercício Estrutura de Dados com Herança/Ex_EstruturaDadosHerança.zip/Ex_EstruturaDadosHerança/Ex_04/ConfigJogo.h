#pragma once
#include "Menu.h"
class ConfigJogo :
	public SubMenu
{
public:
	ConfigJogo();
	~ConfigJogo();
};


#pragma once
#include "Menu.h"
#include "SubMenu.h"

class Jogo
{
public:
	Jogo();
	~Jogo();


	   
protected:
	Menu *menu;
};


#pragma once
#include "Login.h"
#include "ConfigJogo.h"
#include "Load.h"
#include "Save.h"
class SubMenu
{
public:
	SubMenu();
	~SubMenu();

	SubMenu chamarTela(int tela);
};


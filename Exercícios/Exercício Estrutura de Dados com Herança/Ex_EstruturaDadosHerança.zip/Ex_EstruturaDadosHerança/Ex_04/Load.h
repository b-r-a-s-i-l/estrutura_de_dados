#pragma once
#include "Menu.h"
class Load :
	public SubMenu
{
public:
	Load();
	~Load();
};


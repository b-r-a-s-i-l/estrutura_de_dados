#include "GameObjects.h"



GameObjects::GameObjects()
{
}


GameObjects::~GameObjects()
{
}

void GameObjects::carregarObjeto()
{
	//desenha o objeto
}

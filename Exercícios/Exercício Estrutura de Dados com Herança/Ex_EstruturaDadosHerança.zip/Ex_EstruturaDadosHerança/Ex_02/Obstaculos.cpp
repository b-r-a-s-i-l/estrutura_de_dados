#include "Obstaculos.h"



Obstaculos::Obstaculos()
{
}


Obstaculos::~Obstaculos()
{
}

void Obstaculos::carregarObjeto()
{
	// desenha os obst�culos
}

#pragma once
class GameObjects
{
public:
	GameObjects();
	~GameObjects();

	virtual void carregarObjeto();
};


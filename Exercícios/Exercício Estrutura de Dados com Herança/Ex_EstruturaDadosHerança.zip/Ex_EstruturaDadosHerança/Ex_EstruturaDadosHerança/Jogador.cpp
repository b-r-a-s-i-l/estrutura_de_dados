#include "Jogador.h"



Jogador::Jogador()
{
}


Jogador::~Jogador()
{
}

void Jogador::usarItemDoInvent�rio()
{
	inventario.usarItem(1);
}

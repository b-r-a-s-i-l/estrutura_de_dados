#pragma once
#include "Veiculos.h"
class Motos:
	public Veiculos
{
public:
	Motos();
	~Motos();
};


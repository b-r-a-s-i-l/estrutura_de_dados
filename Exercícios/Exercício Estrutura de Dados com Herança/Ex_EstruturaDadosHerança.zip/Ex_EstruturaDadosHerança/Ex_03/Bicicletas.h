#pragma once
#include "Veiculos.h"
class Bicicletas:
	public Veiculos
{
public:
	Bicicletas();
	~Bicicletas();
};


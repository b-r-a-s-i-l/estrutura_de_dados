#include "Motos.h"



Motos::Motos()
{
}


Motos::~Motos()
{
}

#pragma once
#include "Veiculos.h"
class Helicoptero:
	public Veiculos
{
public:
	Helicoptero();
	~Helicoptero();
};


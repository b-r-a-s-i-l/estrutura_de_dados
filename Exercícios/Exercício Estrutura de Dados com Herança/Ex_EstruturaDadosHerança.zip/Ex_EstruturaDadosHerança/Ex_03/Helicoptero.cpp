#include "Helicoptero.h"



Helicoptero::Helicoptero()
{
}


Helicoptero::~Helicoptero()
{
}

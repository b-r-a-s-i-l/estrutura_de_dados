#pragma once
#include "Veiculos.h"
class Carros:
	public Veiculos
{
public:
	Carros();
	~Carros();
};

